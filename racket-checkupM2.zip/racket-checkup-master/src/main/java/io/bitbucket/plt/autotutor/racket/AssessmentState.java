package io.bitbucket.plt.autotutor.racket;

public enum AssessmentState { IN_PROGRESS, FAILED, SUCCEEDED }