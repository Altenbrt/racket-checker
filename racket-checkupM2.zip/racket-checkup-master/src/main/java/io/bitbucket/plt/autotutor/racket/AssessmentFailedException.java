package io.bitbucket.plt.autotutor.racket;

public class AssessmentFailedException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 3307747188539108786L;

}
